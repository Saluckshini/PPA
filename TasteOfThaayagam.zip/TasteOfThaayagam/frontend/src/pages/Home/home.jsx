import React from 'react'
import './Home.css'
const home = () => {
  return (
    <div>
      
    </div>
  )
}

export default home
