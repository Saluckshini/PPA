import React from 'react'
import './placeOrder.css'
const placeOrder = () => {
  return (
    <div>
      
    </div>
  )
}

export default placeOrder
