import logo from './logo.jpg'
import search from './search.png'
import cart from './cart.png'
import bgvideo from './bgvideo.mp4';

export const assets={
    logo,
    search,
    cart
};
export const bgVideo = bgvideo;