
import './Navbar.css';
import { assets } from '../../assets/assets'; // adjust path as needed

const Navbar = () => {
    


  return (
    <div className="navbar">
      {/* Logo */}
      <img src={assets.logo} alt="Logo" className="logo" />

      {/* Center Navigation Links */}
      <ul className="navbar-menu">
        
        <li>Home</li>
        <li>Menu</li>
        <li>Reservation</li>
        <li>About Us</li>
      </ul>

      {/* Right Icons + Button */}
      <div className="navbar-right">
        <img src={assets.search} alt="Search" className="icon" />
        <div className="navbar-cart-wrapper">
          <img src={assets.cart} alt="Cart" className="icon" />
          <div className="dot" />
        </div>
        <button className="signin-btn">Sign In</button>
      </div>
    </div>
  );
};

export default Navbar;
